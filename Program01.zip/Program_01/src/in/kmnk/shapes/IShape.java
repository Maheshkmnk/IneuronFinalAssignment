package in.kmnk.shapes;

public interface IShape {
	public Double area();
	public Double perimeter();
	
}

