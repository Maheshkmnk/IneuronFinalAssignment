package in.kmnk.daofactory;

import in.kmnk.dao.IStudentDao;
import in.kmnk.dao.StudentDaoImpl;

public class StudentDaoFactory {

	private static IStudentDao studentdao = null;

	/*
	 * public StudentDaoFactory() { }
	 */

	public static IStudentDao getStudentService() {
		if (studentdao == null) {
			studentdao = new StudentDaoImpl();
		}
		return studentdao;
	}
}
