package in.kmnk.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "client1")
public interface FeignClient2 {

	@GetMapping("/api/read")
	public ResponseEntity<?> getProducts();

}
