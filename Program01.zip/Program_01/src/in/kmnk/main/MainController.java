package in.kmnk.main;

import java.util.Scanner;

import in.kmnk.shapes.Circle;
import in.kmnk.shapes.IShape;
import in.kmnk.shapes.Parallelogram;
import in.kmnk.shapes.Rectangle;
import in.kmnk.shapes.Square;
import in.kmnk.shapes.Trapezoid;
import in.kmnk.shapes.Triangle;

/*Java program that uses polymorphism by defining an interface called Shape
with methods to calculate the area and perimeter of a shape. Then create classes
that implement the Shape interface for different types of shapes, such as circles and
triangles.*/


public class MainController {

	public static void main(String[] args) {
		IShape shape = null;
		double base;
		double base1;
		double base2;
		double height;
		double side1; 
		double side2;
		double side3;
		double side4;
		double side;

		Scanner sc = new Scanner(System.in);

		System.out.println("Choose which shape area and permeter you want....");

		System.out.println("1. Square");
		System.out.println("2. Rectangle");
		System.out.println("3. Triangle");
		System.out.println("4. Circle");
		System.out.println("5. Parallelogram");
		System.out.println("6. Trapezoid");

		System.out.println("Please enter your choice number:: ");
		int choice = sc.nextInt();

		switch (choice) {

		case 1:
			System.out.println("Enter sides value:: ");
			side = sc.nextDouble();
			shape = new Square(side);
			result(shape);
			break;
		case 2:
			System.out.println("Enter length value:: ");
			double length = sc.nextDouble();
			System.out.println("Enter width value:: ");
			double width = sc.nextDouble();
			shape = new Rectangle(length, width);
			result(shape);
			break;
		case 3:
			System.out.println("Enter base value:: ");
			base = sc.nextDouble();
			System.out.println("Enter height value:: ");
			height = sc.nextDouble();
			System.out.println("Enter side1 value:: ");
			side1 = sc.nextDouble();
			System.out.println("Enter side2 value:: ");
			side2 = sc.nextDouble();
			System.out.println("Enter side3 value:: ");
			side3 = sc.nextDouble();
			shape = new Triangle(base, height, side1, side2, side3);
			result(shape);
			break;
		case 4:
			System.out.println("Enter radius value:: ");
			double radius = sc.nextDouble();
			shape = new Circle(radius);
			result(shape);
			break;
		case 5:
			System.out.println("Enter base value:: ");
			base = sc.nextDouble();
			System.out.println("Enter height value:: ");
			height = sc.nextDouble();
			System.out.println("Enter side1 value:: ");
			side1 = sc.nextDouble();
			System.out.println("Enter side2 value:: ");
			side2 = sc.nextDouble();
			shape = new Parallelogram(base, height, side1, side2);
			result(shape);
			break;
		case 6:
			System.out.println("Enter base1 value:: ");
			base1 = sc.nextDouble();
			System.out.println("Enter base2 value:: ");
			base2 = sc.nextDouble();
			System.out.println("Enter height value:: ");
			height = sc.nextDouble();
			System.out.println("Enter side1 value:: ");
			side1 = sc.nextDouble();
			System.out.println("Enter side2 value:: ");
			side2 = sc.nextDouble();
			System.out.println("Enter side3 value:: ");
			side3 = sc.nextDouble();
			System.out.println("Enter side4 value:: ");
			side4 = sc.nextDouble();
			shape = new Trapezoid(base1, base2, height, side1, side2, side3, side4);
			result(shape);
			break;
		default:
			System.out.println("Enter correct option");
			break;
		}

		sc.close();
	}

	public static void result(IShape shape) {
		System.out.println("Area :: " + shape.area());
		System.out.println("Perimeter:: " + shape.perimeter());
	}
}
