package in.kmnk;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.kmnk.dto.Orders;
import in.kmnk.dto.Product;
import in.kmnk.dto.User;
import in.kmnk.service.IStudent22Service;
import in.kmnk.service.Student22ServiceImpl;

/*Spring Boot application that uses Spring Data JPA to retrieve data from a
database. The application should have entities for users and orders, and should
allow for querying orders by user.
*/


@SpringBootApplication
public class Program21Application {
	static String currentUser = null;
	static IStudent22Service service;
	static Scanner sc = null;
	static Product product = null;

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Program21Application.class, args);

		sc = new Scanner(System.in);
		service = run.getBean(Student22ServiceImpl.class);

		System.out.println("please choose 1.sigIn or 2.SignUp option to enter application");
		switch (sc.nextInt()) {
		case 1:
			signIn();
			getAllProducts();
			break;
		case 2:
			System.out.println("please use you email id/unique name as username");
			signUp();
			getAllProducts();
			break;
		default:
			System.out.println("Please choose correct option");
		}

		Boolean flag = false;
		while (!flag) {
			System.out.println();
			System.out.println(
					"Choose Operation you Want to perform:: \n1.See Your Orders \n2. Buy Product \n3. Sell your Product \n4.See All Products Available \n5.Exit");
			switch (sc.nextInt()) {
			case 1:
				orderByUser();
				break;
			case 2:
				buyProduct();
				break;

			case 3:
				insertProduct();
				break;
			case 4:
				getAllProducts();
				break;
			case 5:
				flag = true;
				break;
			default:
				System.out.println("Please choose correct option");
			}
		}

	}

	public static void signUp() {
		User user = new User();
		System.out.println("Please enter username :: ");
		user.setUname(sc.next());
		System.out.println("Please set your password :: ");
		user.setPassword(sc.next());

		String status = service.createUser(user);
		System.out.println(status);
	}

	public static void signIn() {
		User user = new User();

		System.out.print("Please enter username :: ");
		String username = sc.next();
		System.out.print("Please enter password :: ");
		String password = sc.next();

		Boolean status = service.validateUser(username, password);
		/* System.out.println(status); */

		if (status) {
			System.out.println("Successfully logged in");
			currentUser = username;
		} else {
			System.out.println("failed to login");
		}

	}

	public static void insertProduct() {
		Product product = new Product();
		System.out.println("Please enter product details");
		System.out.println("Please enter product Name :: ");
		product.setName(sc.next());
		System.out.println("Please enter product Price :: ");
		product.setPrice(sc.nextDouble());

		String status = service.createProduct(product);
		System.out.println(status);
	}

	public static void getAllProducts() {

		List<Product> allProducts = service.getAllProducts();
		System.out.println();
		
		for (Product ap : allProducts) {
			System.out.println(ap);
		}
	}

	public static void buyProduct() {
		System.out.println("choose product pid which you want to buy : ");
		Orders order = new Orders();
		product = service.getProductById(sc.nextLong());
		System.out.println("product fetched by id");
		if (product != null) {
			System.out.println("product not null");
			order.setPid(product.getPid());
			;
			order.setPname(product.getName());
			order.setPrice(product.getPrice());
			order.setUsername(currentUser);
		}
		if (currentUser != null) {
			System.out.println("user not null");
			String placeOrder = service.placeOrder(order);
			System.out.println("order placed");
			System.out.println(placeOrder);
		} else {
			System.out.println("please signIn/SignUp to buy");
		}
	}

	public static void orderByUser() {
		List<Orders> ordersByUsername = service.findOrdersByUsername(currentUser);

		if (!ordersByUsername.isEmpty()) {
			for (Orders o : ordersByUsername) {
				System.out.println(o);
			}
		} else {
			System.out.println("Till Now you dont have any orders");
		}
	}
}
