package in.kmnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program30ClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
