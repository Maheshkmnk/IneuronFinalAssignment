package in.kmnk;

//•	Abstract class can provide 100% and as well as partial abstraction also, 
//that means an abstract class can have abstract methods and concrete methods also.
interface Father {
	public void playsCricket();
	abstract public void hockey();
}

interface Mother {
	public void hockey();
}

class Child implements Father, Mother {

	@Override
	public void hockey() {
		System.out.println("plays cricket");
	}

	@Override
	public void playsCricket() {
		System.out.println("plays hockey");
	}

}

public class Interface {
	public static void main(String[] args) {

	}
}
