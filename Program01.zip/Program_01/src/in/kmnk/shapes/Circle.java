package in.kmnk.shapes;

public class Circle implements IShape {

	private static final double pi = 3.14;

	private double radius;

	public Circle(double radius) {
		this.radius = radius;
	}

	@Override
	public Double area() {
		Double area = pi * radius * radius;
		return area;
	}

	@Override
	public Double perimeter() {
		Double perimeter = 2 * pi * radius;
		return perimeter;
	}
}
