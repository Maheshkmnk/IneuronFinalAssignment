package in.kmnk;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import in.kmnk.dto.Student22;
import in.kmnk.util.HibernateUtill;

/*
Java program that uses Hibernate to insert data into a MySQL database
table. The program should use Hibernate to map the table to a Java object and then
insert the data into the table. After inserting the data, the program should retrieve it
from the database and display it on the console.
*/

public class Controller {
	static Session session = HibernateUtill.getsession();
	

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		Student22 student = new Student22();
		
		System.out.println("Please enter record details to save into database");
		System.out.println("Please enter Student Name :: ");
		student.setSname(sc.next());
		System.out.println("Please enter Student Age :: ");
		student.setSage(sc.nextInt());
		System.out.println("Please enter Student Address :: ");
		student.setAddress(sc.next());
		
		
		String status = insertStudent(student);
		System.out.println(status);
		
		List<Student22> studentList = getAllRecords();
		System.out.println("\nTotal Record Available in the DB");

		if (!studentList.isEmpty()) {
			System.out.print("sid\tsname\t\tsage\tsaddress\n");
			for (Student22 std : studentList) {
				System.out.printf("%-8d%-16s%-8d%-16s%n", std.getSid(), std.getSname(), std.getSage(),
						std.getAddress());
			}
		} else {
			System.out.println("No Record found");
		}

		sc.close();
		HibernateUtill.closeSession();
		HibernateUtill.closeSessionFactory();
	}

	public static List<Student22> getAllRecords() {
		
		List<Student22> stdList = Collections.emptyList();
		Query<Student22> createQuery = session.createQuery("FROM in.kmnk.dto.Student22");
		if (createQuery != null) {
			stdList = createQuery.list();
		}
		return stdList;
	}

	public static String insertStudent(Student22 student) {
		Transaction transaction=null;
		boolean flag = false;
		try {
			if (session != null) {
				transaction = session.beginTransaction();
				if (transaction != null) {
					session.save(student);
					flag = true;
				}
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				return "Record inserted successfully";
			} else {
				transaction.rollback();
			}
		}
		return "Record insertion failed";
	}

}
