package in.kmnk.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import in.kmnk.dto.UserLoginDetails;

public interface IUserRepo extends JpaRepository<UserLoginDetails, Long> {

	@Query(value = "FROM UserLoginDetails WHERE username = :username")
	public UserLoginDetails findByUsername(String username);
}
