package in.kmnk.service;

import in.kmnk.dto.UserLoginDetails;

public interface IUserService {
	public Boolean registerUser(UserLoginDetails user);
	
	public Boolean login(String username, String password);
	
	public UserLoginDetails findByUsername(String username);
}
