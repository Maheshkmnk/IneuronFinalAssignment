package in.kmnk.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IStudent22Repo;
import in.kmnk.dto.Student22;

@Service
public class Student22ServiceImpl implements IStudent22Service {

	@Autowired
	private IStudent22Repo repo;

	@Override
	public String inserRecord(Student22 student) {
		System.out.println("In Memory proxy class is :: " + repo.getClass().getName());
		Student22 save = null;
		if (student != null) {
			save = repo.save(student);
		}
		return save != null ? "Record inserted successfully with the id " + student.getSid() : "Record insertion failed";
	}
	
	

}
