package in.kmnk;

import java.util.Scanner;

/*Write a Java programme that takes an integer from the user and throws an exception
if it is negative.Demonstrate Exception handling of same program as solution.*/

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		try {
			System.out.print("Enter a number:: ");
			int number = sc.nextInt();

			if (number < 0)
				throw new IllegalArgumentException("Negative number not allowed, please enter a positive number");

			System.out.println("Successfully read number and the number read is:: " + number);

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
}
