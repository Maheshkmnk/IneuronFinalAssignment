package in.kmnk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import in.kmnk.dao.StudentDaoOperation;
import in.kmnk.dto.Student22;
import in.kmnk.util.HibernateUtill;


/*program should use Hibernate to map the table to a Java object and then update
the data in the table. After updating the data, the program should retrieve it from the
database and display it on the console.*/


public class Controller {

	public static void main(String[] args) throws IOException {

		StudentDaoOperation dao = new StudentDaoOperation();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter record ID to update");

		Student22 oldStudent = dao.getRecordById(sc.nextInt());

		if (oldStudent != null) {
			System.out.println(oldStudent);
			System.out.println("Current details of particular record ID is");

			System.out.print("sid\tsname\tsage\tsaddress\n");
			System.out.print(oldStudent.getSid() + "\t");
			System.out.print(oldStudent.getSname() + "\t");
			System.out.print(oldStudent.getSage() + "\t");
			System.out.print(oldStudent.getAddress() + "\n");

			System.out.print("Do you want to continue to update, please enter Yes or No::");

			String userConfirmationToUpdate = br.readLine();
			Student22 newStudent = new Student22();
			if (userConfirmationToUpdate.equalsIgnoreCase("yes")) {
				newStudent.setSid(oldStudent.getSid());

				System.out.print("please enter new student Name::");
				String newName = br.readLine();
				if (newName != "" && !newName.equalsIgnoreCase(oldStudent.getSname())) {
					newStudent.setSname(newName);
				} else {
					newStudent.setSname(oldStudent.getSname());
				}

				System.out.print("please enter new student Age::");
				String newAge = br.readLine();
				if (newAge != "" && !newAge.equals(Integer.toString(oldStudent.getSage()))) {
					newStudent.setSage(Integer.parseInt(newAge));
				} else {
					newStudent.setSage(oldStudent.getSage());
				}

				System.out.print("please enter new student Address::");
				String newAddress = br.readLine();
				if (newAddress != "" && !newAddress.equalsIgnoreCase(oldStudent.getAddress())) {
					newStudent.setAddress(newAddress);
				} else {
					newStudent.setAddress(oldStudent.getAddress());
				}

			} else {

				System.exit(0);
			}
			String status = dao.updateRecordById(newStudent);
			System.out.println(status);
		} else {
			System.out.println("No Record found");
			System.exit(0);

		}

		Student22 updatedRecord = dao.getRecordById(oldStudent.getSid());
		System.out.println("\nFollowing is updated Record in DB");

		if (updatedRecord != null) {
			System.out.print("sid\tsname\t\tsage\tsaddress\n");
			System.out.printf("%-8d%-16s%-8d%-16s%n", updatedRecord.getSid(), updatedRecord.getSname(),
					updatedRecord.getSage(), updatedRecord.getAddress());
		}

		br.close();
		sc.close();
		HibernateUtill.closeSession();
		HibernateUtill.closeSessionFactory();
	}

}
