package in.kmnk;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

/*
Java program that uses stream api to perform operations on a large data set,
such as sorting or filtering the data.
*/

public class StreamAPI {

	public static void main(String[] args) throws IOException {
		 List<Double> dataset;
	        try {
	            dataset = Files.lines(Paths.get("data.txt"))
	                    .map(Double::parseDouble)
	                    .collect(Collectors.toList());
	        } catch (IOException e) {
	            System.err.println("Error reading the dataset file: " + e.getMessage());
	            return;
	        }

        List<Double> filteredData = dataset.stream()
                .filter(n -> n % 2 == 0) 
                .collect(Collectors.toList());

        System.out.println("Filtered Data:");
        System.in.read();
        filteredData.forEach(System.out::println);

        System.in.read();
        
        List<Double> sortedData = dataset.stream()
                .sorted() 
                .collect(Collectors.toList());

        System.out.println("Sorted Data:");
        System.in.read();
        sortedData.forEach(System.out::println);

	}

}
