package in.kmnk.daofactory;

import in.kmnk.dao.IBlogPostDao;
import in.kmnk.dao.BlogPostDaoImpl;

public class BlogPostDaoFactory {

	private static IBlogPostDao blogPostdao = null;

	public BlogPostDaoFactory() {
	}

	public static IBlogPostDao getStudentService() {
		if (blogPostdao == null) {
			blogPostdao = new BlogPostDaoImpl();
		}
		return blogPostdao;
	}
}
