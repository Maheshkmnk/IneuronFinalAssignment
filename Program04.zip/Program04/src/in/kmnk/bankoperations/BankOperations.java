package in.kmnk.bankoperations;

public class BankOperations {

	public Double deposit(double depositAmount, Double balance) {

		balance = balance + depositAmount;
		System.out.println(balance);
		return balance;
	}

	public void checkBalance(Double balance) {

		System.out.println("Balance:: " + balance);
	}

	public Double withdraw(double withdrawAmount, Double balance) {

		if (withdrawAmount <= balance) {
			balance = balance - withdrawAmount;
			System.out.println("Collect your cash...");
		} else {
			System.out.println("Insufficient Funds");
		}

		return balance;
	}

}
