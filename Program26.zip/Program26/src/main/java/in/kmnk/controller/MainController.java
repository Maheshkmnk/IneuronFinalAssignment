package in.kmnk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kmnk.dto.Product;
import in.kmnk.service.IProductService;

/*Spring Boot application that exposes a REST API for managing a list of
products. The API should allow for creating, updating, deleting, and retrieving
products.*/

@RestController
@RequestMapping("/api")
public class MainController {

	@Autowired
	IProductService service;

	@PostMapping("/create")
	public ResponseEntity<String> insertProduct(@RequestBody Product product) {
		String status = service.createProduct(product);
		System.out.println(status);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}

	@GetMapping("/read")
	public ResponseEntity<?> getRecordById(@RequestBody Product product) {
		Long pid = product.getPid();
		Product outProduct = service.getProductById(pid);
		if (outProduct != null) {
			return new ResponseEntity<Product>(outProduct, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Product Not Found With the Given Id", HttpStatus.OK);
	}

	@DeleteMapping("/delete/{pid}")
	public ResponseEntity<String> deleteRecordById(@PathVariable Long pid) {
		String status = service.deleteProductById(pid);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<String> updateProductById(@RequestBody Product product) {
		String status = service.updateProductById(product);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}

}
