package in.kmnk;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.query.Query;

import in.kmnk.dto.Student22;
import in.kmnk.util.HibernateUtill;

/*
Java program that uses Hibernate to connect to a MySQL database and
retrieve data from a table. The program should use Hibernate to map the table to a
Java object and then display the data on the console.

*/

public class Controller {
	static Session session = null;

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);

		List<Student22> studentList = getAllRecords();

		if (!studentList.isEmpty()) {
			System.out.print("sid\tsname\t\tsage\tsaddress\n");
			for (Student22 std : studentList) {
				System.out.printf("%-8d%-16s%-8d%-16s%n", std.getSid(), std.getSname(), std.getSage(),
						std.getAddress());
			}
		} else {
			System.out.println("No Record found");
		}

		sc.close();
		HibernateUtill.closeSession();
		HibernateUtill.closeSessionFactory();
	}

	public static List<Student22> getAllRecords() {
		session = HibernateUtill.getsession();
		List<Student22> stdList = Collections.emptyList();
		Query<Student22> createQuery = session.createQuery("FROM in.kmnk.dto.Student22");
		if (createQuery != null) {
			stdList = createQuery.list();
		}
		return stdList;
	}

}
