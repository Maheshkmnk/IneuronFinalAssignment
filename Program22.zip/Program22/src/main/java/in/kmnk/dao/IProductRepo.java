package in.kmnk.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.kmnk.dto.Product;

public interface IProductRepo extends JpaRepository<Product, Long> {

}
