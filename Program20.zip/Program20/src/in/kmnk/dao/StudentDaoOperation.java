package in.kmnk.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.kmnk.dto.Student22;
import in.kmnk.util.HibernateUtill;

public class StudentDaoOperation {
	Session session = null;
	Transaction transaction = null;

	public StudentDaoOperation() {
		session = HibernateUtill.getsession();
	}

	public Student22 getRecordById(Integer rid) {
		Student22 student = session.get(Student22.class, rid);
		return student;
	}

	public String updateRecordById(Student22 student) {
		boolean flag = false;
		try {
			transaction = session.beginTransaction();
			if (transaction != null) {
				session.merge(student);
				flag = true;
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				return "Record updated successfully";
			} else {
				transaction.rollback();
			}
		}
		return "Record updation failed";
	}

}
