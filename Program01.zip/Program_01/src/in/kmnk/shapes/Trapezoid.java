package in.kmnk.shapes;

public class Trapezoid implements IShape {

	private double base1;
	private double base2;
	private double height;
	private double side1;
	private double side2;
	private double side3;
	private double side4;

	public Trapezoid(double base1, double base2, double height, double side1, double side2, double side3,
			double side4) {
		this.base1 = base1;
		this.base2 = base2;
		this.height = height;
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
		this.side4 = side4;
	}

	@Override
	public Double area() {
		return ((base1 + base2) * height) / 2;
	}

	@Override
	public Double perimeter() {
		return side1 + side2 + side3 + side4;
	}

}
