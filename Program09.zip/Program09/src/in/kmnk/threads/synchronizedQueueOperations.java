package in.kmnk.threads;

import java.util.LinkedList;
import java.util.Queue;

public class synchronizedQueueOperations {
	Queue<Integer> queue = new LinkedList<Integer>();

	public synchronized void adding(int randomNumber, Integer i, int n) {
		queue.add(randomNumber);
		if (i.equals(n - 1)) {
			notify();
		}
	}

	public synchronized Integer getAndSum() {
		int sum = 0;
		while (queue.isEmpty()) {
			try {
				System.out.println("\nQueue is empty! Consumer thread went into waiting state\n");
				wait();
				System.out.println("\nConsumer Thread resumed its operation....\n");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		while (!queue.isEmpty()) {
			Integer poll = queue.poll();
			// System.out.println(poll);
			sum = sum + poll;

		}
		return sum;

	}

}
