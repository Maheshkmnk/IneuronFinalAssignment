package in.kmnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program271ApplicationTests {

	@Test
	void contextLoads() {
	}

}
