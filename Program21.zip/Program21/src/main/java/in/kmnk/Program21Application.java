package in.kmnk;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.kmnk.dto.Student22;
import in.kmnk.service.IStudent22Service;
import in.kmnk.service.Student22ServiceImpl;

/*
Spring Boot application that inserts data into a MySQL database table using
JPA and Hibernate. The application should use Spring Data JPA to map the table to a
Java object and then insert the data into the table.*/

@SpringBootApplication
public class Program21Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Program21Application.class, args);

		IStudent22Service service = run.getBean(Student22ServiceImpl.class);

		Scanner sc = new Scanner(System.in);
		Student22 student = new Student22();

		System.out.println("Please enter record details to save into database");
		System.out.println("Please enter Student Name :: ");
		student.setSname(sc.next());
		System.out.println("Please enter Student Age :: ");
		student.setSage(sc.nextInt());
		System.out.println("Please enter Student Address :: ");
		student.setAddress(sc.next());

		String status = service.inserRecord(student);
		System.out.println(status);
		sc.close();

	}

}
