package in.kmnk.servicefactory;

import in.kmnk.service.IBlogPostService;
import in.kmnk.service.BlogPostServiceImpl;

public class BlogPostServiceFactory {

	private static IBlogPostService blogPostService = null;

	public BlogPostServiceFactory() {
	}

	public static IBlogPostService getStudentService() {
		if (blogPostService == null) {
			blogPostService = new BlogPostServiceImpl();
		}
		return blogPostService;
	}
}
