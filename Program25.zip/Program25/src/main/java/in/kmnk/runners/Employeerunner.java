package in.kmnk.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.kmnk.dto.Product;
import in.kmnk.service.IProductService;

@Component
public class Employeerunner implements CommandLineRunner {

	@Autowired
	private IProductService dao;

	@Override // main----> run() -----> continue with buisness logic
	public void run(String... args) throws Exception {
		
		System.out.println("\n--------------started------------\n");
		
		System.out.println("\n--------------create------------");
		Product product = new Product();
		product.setName("glass");
		product.setPrice(2222.00);
		
		dao.createProduct(product);
		System.out.println();
		
		System.out.println("\n--------------delete------------");
		dao.deleteProductById(1L);
		System.out.println();
		
		System.out.println("\n--------------AllProducts------------");
		List<Product> allProducts = dao.getAllProducts();
		for(Product p:allProducts) {
			System.out.println(p);
		}
		System.out.println();
		System.out.println();
		
		
		System.out.println("\n--------------productById------------");
		Product productById = dao.getProductById(6L);
		System.out.println(productById);
		System.out.println();
			
	}

}
