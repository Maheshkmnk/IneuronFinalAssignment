package in.kmnk.service;

import java.util.List;

import in.kmnk.dao.IBlogPostDao;
import in.kmnk.daofactory.BlogPostDaoFactory;
import in.kmnk.dto.BlogPost;

public class BlogPostServiceImpl implements IBlogPostService {
	IBlogPostDao studentDao = BlogPostDaoFactory.getStudentService();;

	@Override
	public String insertStudent(BlogPost post) {
		return studentDao.insertStudent(post);
	}

	@Override
	public BlogPost getRecordById(Integer recordId) {
		return studentDao.getRecordById(recordId);
	}

	@Override
	public List<BlogPost> getAllRecords() {
		return studentDao.getAllRecords();
	}

	@Override
	public String updateRecordById(BlogPost post) {
		return studentDao.updateRecordById(post);
	}

	@Override
	public String deleteRecordById(Integer recordId) {
		return studentDao.deleteRecordById(recordId);
	}
}
