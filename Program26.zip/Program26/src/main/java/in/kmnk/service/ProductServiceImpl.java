package in.kmnk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IProductRepo;
import in.kmnk.dto.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo productRepo;

	@Override
	public String createProduct(Product product) {
		Product save = null;
		if (product != null) {
			save = productRepo.save(product);
		}
		return save != null ? "Successfully posted" : "failed to post";
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> productList = productRepo.findAll();
		return productList;
	}

	@Override
	public Product getProductById(Long pid) {
		Product product = null;
		Optional<Product> findById = productRepo.findById(pid);
		if (findById.isPresent()) {
			product = findById.get();
		}
		return product;
	}

	@Override
	public String deleteProductById(Long Id) {

		Optional<Product> findById = productRepo.findById(Id);
		if (findById.isPresent()) {
			productRepo.deleteById(Id);
			return "Product deleted suuccessfully";
		} else {
			return "The Product with the specified id was not available";
		}
	}

	@Override
	public String updateProductById(Product product) {
		Product save = null;
		System.out.println(product.getPid());
		Optional<Product> findById = productRepo.findById(product.getPid());
		if (findById.isPresent()) {
			save = productRepo.save(product);
		}

		return save != null ? "Product updated successfully" : "Product with the give id is not present to update";
	}

}
