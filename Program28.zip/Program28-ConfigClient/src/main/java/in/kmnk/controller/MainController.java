package in.kmnk.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*Spring Boot application that uses Spring Cloud Config Server to externalise
configuration. The application should have a property file that defines properties for
database connection and other application settings.*/

@RestController
@RequestMapping("/api/test")
public class MainController {

	@Value("${spring.datasource.driver-class-name:Config Server not working, please check...}")
	private String driver;

	@Value("${spring.datasource.url:Config Server not working, please check...}")
	private String url;

	@Value("${spring.datasource.username:Config Server not working, please check...}")
	private String username;

	@Value("${spring.datasource.password:Config Server not working, please check...}")
	private String password;

	@GetMapping("/greet")
	public ResponseEntity<String> showMsg() {
		String response = "driver:: " + driver + "\nurl:: " + url + "\nUsername:: " + username + "\nPassword:: "
				+ password;
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
