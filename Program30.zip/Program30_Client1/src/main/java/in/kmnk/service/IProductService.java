package in.kmnk.service;

import java.util.List;

import in.kmnk.dto.Product;

public interface IProductService {

	public List<Product> getAllProducts();

}
