package in.kmnk;

import java.util.Scanner;

import in.kmnk.bankoperations.BankOperations;
import in.kmnk.bankoperations.LoginVerification;

/*Java program that simulates a bank account. The program should allow
users to deposit and withdraw money, check their balance.
*/

public class MainController {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter your 6 digit Account number:: ");
		Integer acNumber = sc.nextInt();

		System.out.println("Please enter your 4 digit pin:: ");
		Integer pin = sc.nextInt();

		LoginVerification account = new LoginVerification();
		Boolean status = account.loginValidation(acNumber, pin);
		// System.out.println(status);

		BankOperations operation = new BankOperations();

		Integer option = 0;
		if (status) {
			while (option != 4) {
				System.out.println("1. Deposit");
				System.out.println("2. Withdraw");
				System.out.println("3. Check Balance");
				System.out.println("4. Exit");

				System.out.print("\nPlease Enter operation number you want to perform:: ");
				option = sc.nextInt();
				switch (option) {

				case 1:
					System.out.print("Enter how much amount you to deposit::");
					double depositAmount = sc.nextDouble();

					Double deposit = operation.deposit(depositAmount, account.getBalance());
					account.setBalance(deposit);

					// System.out.println("\nBalance Amount:: " + account.getBalance());
					break;
				case 2:

					System.out.print("Enter how much amount you to withdraw::");
					double withdrawAmount = sc.nextDouble();

					Double remainBalance = operation.withdraw(withdrawAmount, account.getBalance());
					account.setBalance(remainBalance);

					// System.out.println("\nBalance Amount:: " + account.getBalance());
					break;
				case 3:
					operation.checkBalance(account.getBalance());
					break;
				case 4:
					System.out.println("Thank you for using our App....visit again");
					break;
				default:
					System.out.println("Please choose valid option on given list..");
					break;
				}
			}
		} else {
			System.out.println("Wrong pin, Please verify your pin once");
		}

		sc.close();
	}
}
