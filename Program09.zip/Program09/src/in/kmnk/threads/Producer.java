package in.kmnk.threads;

import java.util.Random;

public class Producer extends Thread {

	private synchronizedQueueOperations queueOperations;

	public Producer(synchronizedQueueOperations queueOperations) {
		this.queueOperations = queueOperations;
		System.out.println("Producer Thread created....\n");
	}

	public void run() {
		Random random = new Random();
		int randomNumber = 0;
		int n=5;
		for (int i = 0; i < n; i++) {
			randomNumber = random.nextInt(10);
			System.out.println("Producer Thread >>> Generated number::" + randomNumber);
			queueOperations.adding(randomNumber,i,n);
		}
		
		System.out.println("\nProducer Thread Execution Ended....");
	}

}
