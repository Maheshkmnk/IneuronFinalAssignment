package in.kmnk.service;

import java.util.List;

import in.kmnk.dto.Product;

public interface IProductService {

	public String createProduct(Product product);

	public List<Product> getAllProducts();

	public Product getProductById(Long Id);
	
	public String deleteProductById(Long Id);
	
	public String updateProductById(Product product);

}
