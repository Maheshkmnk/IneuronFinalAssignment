package in.kmnk.controlloer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.kmnk.dto.Student;
import in.kmnk.util.JdbcUtil;

/*Java servlet that uses session management to maintain the state of the
user across multiple requests. The servlet should store the user's name in a session
object and display it on multiple pages of the web application.*/

@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Student> studentList = doProcess();

		HttpSession session = request.getSession(false);

		Object attributeValue = session.getAttribute("username");

		request.setAttribute("username", attributeValue);
		request.setAttribute("studentList", studentList);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("records.jsp");

		requestDispatcher.forward(request, response);
	}

	private List<Student> doProcess() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<>();
		String queryString = "select sid, sname, sage, saddress from student";

		con = JdbcUtil.getJdbcConnection();
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}

			// System.out.print("sid\t\tsname\t\tsage\t\tsaddress\n");
			if (ps != null) {
				rs = ps.executeQuery();
				while (rs.next()) {
					Student student = new Student();
					student.setSid(rs.getInt(1));
					student.setSname(rs.getString(2));
					student.setSage(rs.getInt(3));
					student.setAddress(rs.getString(4));

					studentList.add(student);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JdbcUtil.closeConnections(con, ps, rs);
		for (Student std : studentList) {
			System.out.println(std);
		}

		JdbcUtil.closeConnections(con, ps, rs);
		return studentList;
	}

}
