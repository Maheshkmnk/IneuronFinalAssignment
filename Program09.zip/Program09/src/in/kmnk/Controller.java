package in.kmnk;

import in.kmnk.threads.Consumer;
import in.kmnk.threads.Producer;
import in.kmnk.threads.synchronizedQueueOperations;

/*
Java program that implements a producer-consumer model using
multithreading. The program should have a producer thread that generates random
numbers and adds them to a queue, and a consumer thread that reads numbers
from the queue and calculates their sum. The program should use synchronization to
ensure that the queue is accessed by only one thread at a time
*/

public class Controller {

	public static void main(String[] args) {

		synchronizedQueueOperations queueOperations = new synchronizedQueueOperations();
		Producer producer = new Producer(queueOperations);
		Consumer consumer = new Consumer(queueOperations);

		producer.start();
		consumer.start();

	}

}
