package in.kmnk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IProductRepo;
import in.kmnk.dto.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo productRepo;

	@Override
	public String createProduct(Product product) {
		Product save = null;
		if (product != null) {
			save = productRepo.save(product);
		}
		return save != null ? "Successfully posted" : "failed to post";
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> productList = productRepo.findAll();
		return productList;
	}

	@Override
	public Product getProductById(Long pid) {
		Product product = null;
		Optional<Product> findById = productRepo.findById(pid);
		if (findById.isPresent()) {
			product = findById.get();
		}
		return product;
	}

}
