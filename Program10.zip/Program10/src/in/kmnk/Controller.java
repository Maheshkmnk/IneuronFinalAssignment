package in.kmnk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
 Java program that reads a set of integers from the user and stores them in a
List. The program should then find the second largest and second smallest elements
in the List.

*/

public class Controller {

	public static void main(String[] args) {
		List<Integer> userInput = new ArrayList<Integer>();

		System.out.print("Enter count, How many numbers you want to insert:: ");
		Scanner sc = new Scanner(System.in);
		int count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			System.out.print("\nEnter value of " + (i + 1) + " :: ");
			int value = sc.nextInt();
			userInput.add(value);
		}

		Collections.sort(userInput);

		System.out.println("\nSecond smallest Value:: " + userInput.get((userInput.size() + 1) - userInput.size()));
		System.out.println("Second largest Value:: " + userInput.get((userInput.size() - 2)));

		System.out.print("\nComplete List of elements in ascending order :: ");
		for (Integer e : userInput) {
			System.out.print(e + " ");
		}
		sc.close();
	}

}
