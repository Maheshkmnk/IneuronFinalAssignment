package in.kmnk.service;

import java.util.List;

import in.kmnk.dto.Student;

public interface IStudentService {

	public String insertStudent(Student student);

	public Student getRecordById(Integer rId);

	public List<Student> getAllRecords();

	public String updateRecordById(Student student);

	public String deleteRecordById(Integer id);

}
