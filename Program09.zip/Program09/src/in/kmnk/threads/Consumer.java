package in.kmnk.threads;

public class Consumer extends Thread {

	private synchronizedQueueOperations queueOperations;

	public Consumer(synchronizedQueueOperations queueOperations) {
		this.queueOperations = queueOperations;
		System.out.println("Consumer Thread created....\n");
	}

	public void run() {

		Integer sum = queueOperations.getAndSum();

		System.out.println("Consumer Thread >>> Sum of values in queue:: " + sum);
		System.out.println("\nConsumer Thread Execution Ended....");
	}
}
