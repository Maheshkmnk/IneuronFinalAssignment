package in.kmnk;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/*
web application that lets users create and view blog posts. The web
application should use the MVC pattern, with servlets as controllers, JSPs as views,
and a database as the model. Users should be able to create new blog posts by
filling out a form that includes a title, description, and content. The web application
should use a servlet to store the blog post data in the database. Users should also be
able to view all the blog posts on a separate page, and the web application should
use a servlet to retrieve the blog post data from the database and display it in a
formatted way.

*/

@WebServlet("/user")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String username = request.getParameter("username");
		System.out.println(username);
		request.setAttribute(username, username);

		HttpSession session = request.getSession();
		session.setAttribute("username", username);

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("getallposts");

		requestDispatcher.forward(request, response);
	}

}
