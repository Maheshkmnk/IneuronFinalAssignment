package in.kmnk;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.kmnk.util.JdbcUtil;

/*
Java program that connects to a PostgreSQL database and executes a
batch update. The program should read the input data from a file and insert it into the
database using JDBC batch updates.

*/

public class Controller {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String queryString = "INSERT INTO products (id, pname, price) VALUES (?, ?, ?)";

		con = JdbcUtil.getJdbcConnection();
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}

			if (ps != null) {
				BufferedReader read = new BufferedReader(new FileReader("src/data.txt"));

				String temp;
				while ((temp = read.readLine()) != null) {
					String[] data = temp.split(",");

					ps.setInt(1, Integer.parseInt(data[0]));
					ps.setString(2, data[1]);
					ps.setDouble(3, Double.parseDouble(data[2]));

					ps.addBatch();
				}

				int[] executeBatch = ps.executeBatch();
				if (executeBatch != null) {
					System.out.println("Data Inserted successfully");
				}
				read.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JdbcUtil.closeConnections(con, ps, rs);

	}

}
