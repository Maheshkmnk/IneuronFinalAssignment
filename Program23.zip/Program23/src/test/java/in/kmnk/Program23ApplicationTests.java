package in.kmnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program23ApplicationTests {

	@Test
	void contextLoads() {
	}

}
