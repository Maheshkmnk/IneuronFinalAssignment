package in.kmnk.controlloer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import in.kmnk.dto.Student;
import in.kmnk.util.JdbcUtil;

/*Java servlet that reads the data from a MySQL database table and displays it
in an HTML table on the web page. The servlet should use JDBC to connect to the
database and retrieve the data*/


@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Student> studentList = doProcess();

		request.setAttribute("studentList", studentList);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("records.jsp");

		requestDispatcher.forward(request, response);
	}

	private List<Student> doProcess() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<>();
		String queryString = "select sid, sname, sage, saddress from student";

		con = JdbcUtil.getJdbcConnection();
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}

			// System.out.print("sid\t\tsname\t\tsage\t\tsaddress\n");
			if (ps != null) {
				rs = ps.executeQuery();
				while (rs.next()) {
					Student student = new Student();
					student.setSid(rs.getInt(1));
					student.setSname(rs.getString(2));
					student.setSage(rs.getInt(3));
					student.setAddress(rs.getString(4));

					studentList.add(student);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JdbcUtil.closeConnections(con, ps, rs);
		for (Student std : studentList) {
			System.out.println(std);
		}

		JdbcUtil.closeConnections(con, ps, rs);
		return studentList;
	}

}

/*
 * // Create a Thymeleaf context and add the student list as a variable Context
 * thymeleafContext = new Context(); thymeleafContext.setVariable("studentList",
 * studentList);
 * 
 * TemplateEngine templateEngine = new TemplateEngine(); // Use the Thymeleaf
 * template engine to process the template String renderedHtml =
 * templateEngine.process("records.html", thymeleafContext);
 * 
 * // Set the content type and write the rendered HTML to the response
 * response.setContentType("text/html");
 * response.getWriter().write(renderedHtml);
 */
