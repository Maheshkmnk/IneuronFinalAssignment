package in.kmnk;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import in.kmnk.dto.Student;
import in.kmnk.service.IStudentService;
import in.kmnk.servicefactory.StudentServiceFactory;

/*
Write a Java program that uses JDBC to implement a simple CRUD (create, read,
update, delete) application. The program should allow users to add, view, update,
and delete records in a MySQL database table.
*/

public class Controller {
	public static void main(String[] args) throws IOException {
		IStudentService studentService = StudentServiceFactory.getStudentService();

		Scanner sc = new Scanner(System.in);

		System.out.println("Choose which operation you want to perform....");

		System.out.println("1. Insert a record");
		System.out.println("2. Get Record by ID");
		System.out.println("3. Get All Records");
		System.out.println("4. Update Record by ID");
		System.out.println("5. Delete Record by ID");

		System.out.println("Please enter your choice number:: ");
		int choice = sc.nextInt();
		Student student = new Student();

		switch (choice) {
		case 1:
			System.out.println("Please enter record details");
			System.out.println("Please enter Student Name :: ");
			student.setSname(sc.next());
			System.out.println("Please enter Student Age :: ");
			student.setSage(sc.nextInt());
			System.out.println("Please enter Student Address :: ");
			student.setAddress(sc.next());
			String status = studentService.insertStudent(student);
			System.out.println(status);
			break;

		case 2:
			System.out.println("Please enter record ID");
			student = studentService.getRecordById(sc.nextInt());
			if (student != null) {

				System.out.print("sid\tsname\tsage\tsaddress\n");
				System.out.print(student.getSid() + "\t");
				System.out.print(student.getSname() + "\t");
				System.out.print(student.getSage() + "\t");
				System.out.print(student.getAddress() + "\n");
			}else {
				System.out.println("record not found");
			}

			break;
		case 3:
			List<Student> studentList = studentService.getAllRecords();

			System.out.print("sid\tsname\t\tsage\tsaddress\n");
			for (Student std : studentList) {
				System.out.printf("%-8d%-16s%-8d%-16s%n", std.getSid(), std.getSname(), std.getSage(),
						std.getAddress());

			}

			break;

		case 4:
			System.out.println("Please enter record ID to update");

			Student oldStudent = studentService.getRecordById(sc.nextInt());

			if (oldStudent != null) {

				System.out.println("Current details of particular record ID is");

				System.out.print("sid\tsname\tsage\tsaddress\n");
				System.out.print(oldStudent.getSid() + "\t");
				System.out.print(oldStudent.getSname() + "\t");
				System.out.print(oldStudent.getSage() + "\t");
				System.out.print(oldStudent.getAddress() + "\n");

				System.out.print("Do you want to continue to update, please enter Yes or No::");

				String userConfirmationToUpdate = sc.next();
				Student newStudent = new Student();
				if (userConfirmationToUpdate.equalsIgnoreCase("yes")) {
					newStudent.setSid(oldStudent.getSid());

					System.out.print("please enter new student Name::");
					String newName = sc.next();
					if (newName != null && !newName.equalsIgnoreCase(oldStudent.getSname())) {
						newStudent.setSname(newName);
					} else {
						newStudent.setSname(oldStudent.getSname());
					}

					System.out.print("please enter new student Age::");
					Integer newAge = sc.nextInt();
					if (newAge != null && !newAge.equals(oldStudent.getSage())) {
						newStudent.setSage(newAge);
					} else {
						newStudent.setSage(oldStudent.getSage());
					}

					System.out.print("please enter new student Address::");
					String newAddress = sc.next();
					if (newAddress != null && !newAddress.equalsIgnoreCase(oldStudent.getAddress())) {
						newStudent.setAddress(newAddress);
					} else {
						newStudent.setAddress(oldStudent.getAddress());
					}

				} else {
					break;
				}
				status = studentService.updateRecordById(newStudent);
				System.out.println(status);
			}

			break;

		case 5:
			System.out.println("Please enter record ID to delete");
			status = studentService.deleteRecordById(sc.nextInt());
			System.out.println(status);
			break;
		default:
			System.out.print("Please enter proper option");
		}

		sc.close();

	}

}
