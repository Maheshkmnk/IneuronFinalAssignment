package in.kmnk.aspects;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	@Before("execution(* in.kmnk.service.*.*(..))")
    public void beforeMethodCall(JoinPoint joinPoint) {
		System.out.println("\n@Before Advisor called");
		
		String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();

        
        System.out.println("\nEntering method: " + methodName);
        System.out.println("Input parameters: " + Arrays.toString(args));
    }

    @AfterReturning(pointcut = "execution(* in.kmnk.service.*.*(..))", returning = "result")
    public void afterMethodCall(JoinPoint joinPoint, Object result) {
    	System.out.println("\n@AfterReturning Advisor called");
    	
    	String methodName = joinPoint.getSignature().getName();

        System.out.println("\nExiting method: " + methodName);
        System.out.println("Output: " + result);
    }

    @AfterThrowing(pointcut = "execution(* in.kmnk.service.*.*(..))", throwing = "exception")
    public void afterMethodThrowsException(JoinPoint joinPoint, Exception exception) {
    	System.out.println("\n@AfterThrowing Advisor called");
    	
    	String methodName = joinPoint.getSignature().getName();

        System.out.println("\nException in method: " + methodName);
        System.out.println("Exception details: " + exception.getMessage());
    }

    @Around("execution(* in.kmnk.service.*.*(..))")
    public Object aroundMethodCall(ProceedingJoinPoint joinPoint) throws Throwable {
       
    	System.out.println("\n@Around Advisor called");
    	
    	String methodName = joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();

        System.out.println("\nEntering method: " + methodName);
        System.out.println("Input parameters: " + Arrays.toString(args));

        Object result;
        try {
            result = joinPoint.proceed();
        } catch (Exception exception) {
            System.out.println("\nException in method: " + methodName);
            System.out.println("Exception details: " + exception.getMessage());
            throw exception;
        }

        System.out.println("\nExiting method: " + methodName);
        System.out.println("Output: " + result);
        System.out.println("\n@Around Advisor ended");
        return result;
    }
}
