package in.kmnk.service;

import java.util.List;

import in.kmnk.dto.Orders;
import in.kmnk.dto.Product;
import in.kmnk.dto.User;

public interface IStudent22Service {
	public String createUser(User user);

	public String createProduct(Product product);

	public String placeOrder(Orders order);

	public List<Product> getAllProducts();

	public Product getProductById(Long Id);

	public List<Orders> findOrdersByUsername(String usernmae);

	public Boolean validateUser(String username, String password);

	List<Orders> getAllOrders();

}
