package in.kmnk.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*Java servlet that reads the name of the user from a form and displays a
welcome message on the web page. The servlet should use the GET method to read
the input data from the user*/

@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");

		request.setAttribute("username", username);
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("welcome.jsp");

		requestDispatcher.forward(request, response);

		// PrintWriter out = response.getWriter();
		// out.print("<h1>Welocome to servlet-jsp world "+parameter+" </h1>");
	}
}
