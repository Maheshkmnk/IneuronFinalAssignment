package in.kmnk.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.kmnk.dto.Student22;

public interface IStudent22Repo extends JpaRepository<Student22, Integer> {

}
