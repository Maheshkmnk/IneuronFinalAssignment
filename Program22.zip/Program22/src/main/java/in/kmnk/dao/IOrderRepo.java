package in.kmnk.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.kmnk.dto.Orders;

public interface IOrderRepo extends JpaRepository<Orders, Long> {

	/*
	 * @Query("SELECT o FROM Order o WHERE o.username = :username") public
	 * List<Order> findOrdersByUsername(String username);
	 */
}
