package in.kmnk.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.kmnk.dto.UserLoginDetails;
import in.kmnk.service.IUserService;

/*
Spring MVC application that allows users to register and login. The
application should have a registration form that accepts user details and a login form
that authenticates users.*/


@Controller
public class MainController {

	@Autowired
	IUserService userService;

	@GetMapping("/")
	public String loadLandingPage() {
		return "home";
	}

	@PostMapping("/signup")
	public String signUp(HttpServletRequest request, @RequestParam String username, @RequestParam String password,
			Model model) {
		UserLoginDetails user = new UserLoginDetails();
		user.setUsername(username);
		user.setPassword(password);

		Boolean status = userService.registerUser(user);
		if (status) {
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			return "home";
		} else {
			String msg = "Username already existed, please try again with different Username";
			model.addAttribute("msg", msg);
			System.out.println("user already existed");
			return "signup";
		}

	}

	@GetMapping("/signin")
	public String signin(HttpServletRequest request, @RequestParam String username, @RequestParam String password,
			Model model) {
		Boolean status = userService.login(username, password);
		if (status) {
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			return "home";
		} else {
			model.addAttribute("msg", "Login failed, please try again");
		}

		return "signin";
	}

	@GetMapping("/signout")
	public String signOut(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		return "home";
	}
}
