package in.kmnk;

//•	Abstract class can provide 100% and as well as partial abstraction also, 
//that means an abstract class can have abstract methods and concrete methods also.
abstract class BankingSystem{
	public void welcomeNote() {
		System.out.println("welcome our Banking...");
	}
	
	abstract public double withdraw(double currentBalance, double withdrawAmount);
	abstract public double checkBalance(double currentBalance);
}

class Axis extends BankingSystem{

	@Override
	public double withdraw(double currentBalance, double withdrawAmount) {
		
		return 0;
	}

	@Override
	public double checkBalance(double currentBalance) {
		
		return 0;
	}
	
}

public class Abstraction {
	public static void main(String[] args) {
		
	}
}
