package in.kmnk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/*Spring Boot application that uses Spring AOP to log method calls. The
application should have a service class with methods that perform operations. The
application should use Spring AOP to log the method calls with input and output
parameters to the console.*/



@SpringBootApplication
@ComponentScan
public class Program30ClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Program30ClientApplication.class, args);
	}
}
