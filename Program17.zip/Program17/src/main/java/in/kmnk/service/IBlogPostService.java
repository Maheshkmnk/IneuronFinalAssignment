package in.kmnk.service;

import java.util.List;

import in.kmnk.dto.BlogPost;

public interface IBlogPostService {

	public String insertStudent(BlogPost post);

	public BlogPost getRecordById(Integer recordId);

	public List<BlogPost> getAllRecords();

	public String updateRecordById(BlogPost post);

	public String deleteRecordById(Integer recordId);

}
