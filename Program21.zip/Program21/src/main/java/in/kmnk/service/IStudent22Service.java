package in.kmnk.service;

import in.kmnk.dto.Student22;

public interface IStudent22Service {
	public String inserRecord(Student22 student);
}
