package in.kmnk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IProductRepo;
import in.kmnk.dto.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductRepo productRepo;

	@Override
	public List<Product> getAllProducts(String sortField, String sortOrder, int page, int size) {
		Sort.Direction direction = sortOrder.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
		Sort sort = Sort.by(direction, sortField);
		Pageable pageable = PageRequest.of(page, size, sort);

		
		Page<Product> pageProduct = productRepo.findAll(pageable);
		for(Product out:pageProduct) {
			System.out.println("In::"+out);
		}
		List<Product> productList = pageProduct.getContent();
		return productList;
	}
}
