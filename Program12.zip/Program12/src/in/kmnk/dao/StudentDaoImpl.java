package in.kmnk.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.kmnk.dto.Student;
import in.kmnk.util.JdbcUtil;

public class StudentDaoImpl implements IStudentDao {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public StudentDaoImpl() {
		con = JdbcUtil.getJdbcConnection();
	}

	@Override
	public String insertStudent(Student student) {

		String queryString = "insert into studentrecords(`sname`, `sage`, `saddress`)values(?,?,?)";

		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setString(1, student.getSname());
				ps.setInt(2, student.getSage());
				ps.setString(3, student.getAddress());

				int rowCount = ps.executeUpdate();
				if (rowCount != 0) {
					return "Successfully record inserted";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return "Record insertion failed";
	}
   
	@Override
	public Student getRecordById(Integer rid) {
		Student student = new Student();
		String queryString = "select sname, sage, saddress from studentrecords where sid=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setInt(1, rid);
				rs = ps.executeQuery();
			}
			if (rs != null) {
				while (rs.next()) {
					System.out.println("sname"+rs.getString("sname"));
					System.out.println("sage"+rs.getInt("sage"));
					System.out.println("saddress"+rs.getString("saddress"));
					student.setSid(rid);
					student.setSname(rs.getString("sname"));
					student.setSage(rs.getInt("sage"));
					student.setAddress(rs.getString("saddress"));
					return student;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Student> getAllRecords() {
		List<Student> std = new ArrayList<>();
		String queryString = "select sid, sname, sage, saddress from studentrecords";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				rs = ps.executeQuery();
				while (rs.next()) {

					Student student = new Student();
					student.setSid(rs.getInt("sid"));
					student.setSname(rs.getString("sname"));
					student.setSage(rs.getInt("sage"));
					student.setAddress(rs.getString("saddress"));
					std.add(student);
				}

				return std;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String updateRecordById(Student student) {
		String queryString = "update studentrecords set sname=?, sage=?, saddress=? where sid=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setString(1, student.getSname());
				ps.setInt(2, student.getSage());
				ps.setString(3, student.getAddress());
				ps.setInt(4, student.getSid());

				int rowCount = ps.executeUpdate();
				if (rowCount != 0) {
					return "Record updated successfully";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Record updation failed";
	}

	@Override
	public String deleteRecordById(Integer rid) {

		String queryString = "delete from studentrecords where sid=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setInt(1, rid);

				int rowCount = ps.executeUpdate();

				if (rowCount != 0) {
					return "Record Deleted successfully for the given id " + rid;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return "Record deletion failed for the given id " + rid;
	}

}
