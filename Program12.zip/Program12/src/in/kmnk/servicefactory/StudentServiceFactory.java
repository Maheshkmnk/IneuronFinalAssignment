package in.kmnk.servicefactory;

import in.kmnk.service.IStudentService;
import in.kmnk.service.StudentServiceImpl;

public class StudentServiceFactory {

	private static IStudentService studentService = null;

	/*
	 * public StudentServiceFactory() { }
	 */

	public static IStudentService getStudentService() {
		if (studentService == null) {
			studentService = new StudentServiceImpl();
		}
		return studentService;
	}
}
