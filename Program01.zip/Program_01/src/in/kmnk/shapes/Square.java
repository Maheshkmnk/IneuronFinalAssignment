package in.kmnk.shapes;

public class Square implements IShape {

	private double side;

	public Square(double side) {
		this.side = side;
	}

	@Override
	public Double area() {
		return side * side;

	}

	@Override
	public Double perimeter() {
		return 4 * side;
	}

}
