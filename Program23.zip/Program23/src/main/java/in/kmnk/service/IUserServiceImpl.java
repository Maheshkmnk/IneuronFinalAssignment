package in.kmnk.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IUserRepo;
import in.kmnk.dto.UserLoginDetails;

@Service
public class IUserServiceImpl implements IUserService {

	@Autowired
	IUserRepo userRepo;

	@Override
	public Boolean registerUser(UserLoginDetails user) {
		UserLoginDetails findByUsername = null;
		findByUsername = userRepo.findByUsername(user.getUsername());
		if (findByUsername==null && user != null) {
			userRepo.save(user);
			return true;
		}
		return false;
	}

	@Override
	public Boolean login(String username, String password) {
		UserLoginDetails findByUsername = null;
		findByUsername = userRepo.findByUsername(username);
		if (findByUsername != null) {
			if (findByUsername.getUsername().equalsIgnoreCase(username)
					&& findByUsername.getPassword().equalsIgnoreCase(password)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public UserLoginDetails findByUsername(String username) {
		UserLoginDetails findByUsername = userRepo.findByUsername(username);
		return findByUsername;
	}

}
