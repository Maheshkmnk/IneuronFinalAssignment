package in.kmnk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.kmnk.util.JdbcUtil;

/*
Java program that connects to a MySQL database using JDBC. The program
should read data from a table and display the results in the console
*/

public class Controller {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String queryString = "select sid, sname, sage, saddress from student";

		con = JdbcUtil.getJdbcConnection();
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			
			System.out.print("sid\t\tsname\t\tsage\t\tsaddress\n");
			if(ps!=null) {
				rs = ps.executeQuery();
				while(rs.next()) {
					System.out.print(rs.getInt(1)+"\t\t");
					System.out.print(rs.getString(2)+"\t\t");
					System.out.print(rs.getInt(3)+"\t\t");
					System.out.print(rs.getString(4)+"\n");
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.closeConnections(con, ps, rs);

	}

}
