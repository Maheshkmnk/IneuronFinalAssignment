package in.kmnk.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.kmnk.dao.IOrderRepo;
import in.kmnk.dao.IProductRepo;
import in.kmnk.dao.IUserRepo;
import in.kmnk.dto.Orders;
import in.kmnk.dto.Product;
import in.kmnk.dto.User;

@Service
public class Student22ServiceImpl implements IStudent22Service {

	@Autowired
	private IUserRepo userRepo;

	@Autowired
	private IProductRepo productRepo;

	@Autowired
	private IOrderRepo orderRepo;

	@Override
	public String placeOrder(Orders order) {
		Orders save = null;
		if (order != null) {
			save = orderRepo.save(order);
		}
		return save != null ? "successfully order placed" : "order failed";
	}

	@Override
	public String createUser(User user) {
		User userSaved = null;
		Boolean flag = userRepo.findByUsername(user.getUname());
		if (!flag) {
			if (user != null) {
				userSaved = userRepo.save(user);
			}
		} else {
			return "user name already existed";
		}
		return userSaved != null ? "registration successfull" : "registration failed";
	}

	@Override
	public String createProduct(Product product) {
		Product save = null;
		if (product != null) {
			save = productRepo.save(product);
		}
		return save != null ? "Successfully posted" : "failed to post";
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> productList = productRepo.findAll();
		return productList;
	}

	@Override
	public List<Orders> getAllOrders() {
		List<Orders> productList = orderRepo.findAll();
		return productList;
	}

	@Override
	public Product getProductById(Long pid) {
		Product product = null;
		Optional<Product> findById = productRepo.findById(pid);
		if (findById.isPresent()) {
			product = findById.get();
		}
		return product;
	}

	@Override
	public List<Orders> findOrdersByUsername(String usernmae) {
		List<Orders> orderListByUser = new ArrayList<>();
		List<Orders> allOrdersList = orderRepo.findAll();
		for (Orders o : allOrdersList) {
			if (o.getUsername().equalsIgnoreCase(usernmae)) {
				orderListByUser.add(o);
			}
		}
		return orderListByUser;
	}

	@Override
	public Boolean validateUser(String username, String password) {
		List<User> usersList = userRepo.findAll();
		for (User user : usersList) {
			if (user.getUname().equalsIgnoreCase(username) && user.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

}
