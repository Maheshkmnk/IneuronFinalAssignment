package in.kmnk.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*
Write a Java program that implements a producer-consumer model using
multithreading. The program should have a producer thread that generates random
numbers and adds them to a queue, and a consumer thread that reads numbers
from the queue and calculates their sum. The program should use synchronization to
ensure that the queue is accessed by only one thread at a time.
*/

public class JdbcUtil {

	private static Connection con = null;

	private JdbcUtil() {
	}

	static {
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("Driver Class loaded");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public static Connection getJdbcConnection() {
		try {
			con = DriverManager.getConnection("jdbc:mysql:///practicedb", "root", "KMNK");
			System.out.println("Connection established\n");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public static void closeConnections(Connection con, PreparedStatement ps, ResultSet rs) {
		try {
			System.out.println("\nCleaning process started...");
			if (rs != null) {
				con.close();
				System.out.println("ResultSet object Closed");
			}
			if (ps != null) {
				ps.close();
				System.out.println("PreparedStatement object Closed");
			}
			if (con != null) {
				con.close();
				System.out.println("Connection object Closed");
			}
			System.out.println("----------Ended----------");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
