package in.kmnk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
Java program that implements a binary search algorithm. The program
should accept user input for the target value and search for it in a sorted array. The
program should return the index of the target value if found or a message if not
found.
*/

class BinarySearchAlgorithm {

	public void search(Integer searchValue) {
		List<Integer> array = new ArrayList<Integer>(
				Arrays.asList(1, 8, 6, 10, 3, 2, 7, 9, 5, 4, 11, 91, 33, 22, 88, 12));
		Collections.sort(array);

		System.out.println("\nBefore sorted Array");
		for (int i = 0; i < array.size(); i++) {
			System.out.print(" " + array.get(i));
		}
		System.out.println("\n\nAfter sorted Array");
		for (int i = 0; i < array.size(); i++) {
			System.out.print(" " + i);
		}
		System.out.println();

		int max = array.size() - 1;
		int initial = 0;
		int mid = max / 2;
		boolean flag = false;

		// System.out.println("initial ::" + initial + " && max::" + max + " && mid::" +
		// mid);

		if (searchValue <= array.get(max)) {
			while (!flag) {

				if (array.get(mid) == searchValue) {
					flag = true;
					// System.out.println("initial ::" + initial + "&& max::" + max);
					// System.out.println(mid + "::" + array.get(mid) + "==== searchValue::" +
					// searchValue);
					System.out.println("\nGiven value found at index number:: " + mid);

				} else if (array.get(mid) > searchValue && mid != max) {
					max = mid;
					// System.out.println(mid + "::" + array.get(mid) + "==== searchValue::" +
					// searchValue);
					// System.out.println("initial ::" + initial + "&& max::" + max);
					mid = (initial + max) / 2;

					// System.out.println(mid);
				} else if (array.get(mid) < searchValue && initial != mid) {
					initial = mid;
					//System.out.println("initial ::" + initial + "&& max::" + max);
					//System.out.println(mid + "::" + array.get(mid) + "==== searchValue::" + searchValue);
					mid = ((initial + max) / 2) + 1;

					//System.out.println(mid);

				} else {
					flag = true;
					System.out.println("Given value not found!..");
				}
			}
		} else {
			System.out.println("Given value not found!..");
		}

	}
}

public class Controller {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter search value:: ");
		int searchValue = sc.nextInt();

		BinarySearchAlgorithm bsa = new BinarySearchAlgorithm();
		bsa.search(searchValue);

		sc.close();
	}
}
