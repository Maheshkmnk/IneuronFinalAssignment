package in.kmnk.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="client2")
public interface FeignClient1 {

	@GetMapping("/api/read")
	public ResponseEntity<?> getProducts();
	
	
}
