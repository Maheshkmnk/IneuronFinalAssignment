package in.kmnk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Program281Application {

	public static void main(String[] args) {
		SpringApplication.run(Program281Application.class, args);
	}

}
