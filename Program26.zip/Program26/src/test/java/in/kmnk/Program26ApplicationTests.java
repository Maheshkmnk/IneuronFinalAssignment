package in.kmnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Program26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
