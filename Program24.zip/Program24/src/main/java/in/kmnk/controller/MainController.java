package in.kmnk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kmnk.dto.Product;
import in.kmnk.service.IProductService;

/*Spring Boot application that uses Spring MVC to create a REST API. The
API should accept a JSON request with data and insert it into a MySQL database
table using JPA and Hibernate. The application should use Spring Data JPA to map
the table to a Java object and then insert the data into the table*/

@RestController
@RequestMapping("/api")
public class MainController {

	@Autowired
	IProductService service;

	@PostMapping("/create")
	public ResponseEntity<String> insertProduct(@RequestBody Product product) {

		String status = service.createProduct(product);
		System.out.println(status);
		
		return new ResponseEntity<String>(status, HttpStatus.OK) ;
	}

	
	

}
