package in.kmnk.bankoperations;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LoginVerification {
	private double balance;

	private ObjectMapper objectMapper;
	private File credentialsFile;
	Map<Integer, Integer> credentials;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getBalance(double balance) {
		return balance;
	}

	public LoginVerification() {
		balance = 0.00;
		objectMapper = new ObjectMapper();
		credentialsFile = new File("src/credentials.json");
		credentials = new HashMap<>();

		loadCredentials();
	}

	public void loadCredentials() {
		try {
			List<Map<String, Object>> credentialsList = objectMapper.readValue(credentialsFile,
					new TypeReference<List<Map<String, Object>>>() {
					});
			for (Map<String, Object> credential : credentialsList) {
				int accountNumber = (int) credential.get("accountNumber");
				int pin = (int) credential.get("pin");
				//System.out.println(accountNumber + "::" + pin);
				credentials.put(accountNumber, pin);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Boolean loginValidation(Integer accountNumber, Integer pin) {

		Integer actualPin = credentials.get(accountNumber);
		//System.out.println("\n" + actualPin + "::" + pin);
		if (actualPin != null && actualPin.equals(pin)) {
			return true;
		}
		return false;
	}

}
