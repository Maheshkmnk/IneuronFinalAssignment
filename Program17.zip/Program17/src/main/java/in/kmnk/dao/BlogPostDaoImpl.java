package in.kmnk.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.kmnk.dto.BlogPost;
import in.kmnk.util.JdbcUtil;

public class BlogPostDaoImpl implements IBlogPostDao {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public BlogPostDaoImpl() {
		con = JdbcUtil.getJdbcConnection();
	}

	@Override
	public String insertStudent(BlogPost post) {

		String queryString = "insert into blogposts(`title`, `description`, `content`)values(?,?,?)";

		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setString(1, post.getBlogTitle());
				ps.setString(2, post.getBlogDescription());
				ps.setString(3, post.getBlogContent());

				int rowCount = ps.executeUpdate();
				if (rowCount != 0) {
					return "Successfully Blog Posted";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return "Somthing Went Wrog Please Try Again";
	}

	@Override
	public BlogPost getRecordById(Integer rid) {
		BlogPost post = new BlogPost();
		String queryString = "select title, description, content from blogposts where id=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setInt(1, rid);
				rs = ps.executeQuery();
			}
			if (rs != null) {
				while (rs.next()) {
					post.setBlogId(rid);
					post.setBlogTitle(rs.getString("title"));
					post.setBlogDescription(rs.getString("description"));
					post.setBlogContent(rs.getString("content"));
				}
				return post;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<BlogPost> getAllRecords() {
		List<BlogPost> postList = new ArrayList<>();
		String queryString = "select id, title, description, content from blogposts";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				rs = ps.executeQuery();
				while (rs.next()) {

					BlogPost post = new BlogPost();
					post.setBlogId(rs.getInt("id"));
					post.setBlogTitle(rs.getString("title"));
					post.setBlogDescription(rs.getString("description"));
					post.setBlogContent(rs.getString("content"));
					postList.add(post);
				}

				return postList;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String updateRecordById(BlogPost post) {
		String queryString = "update blogposts set title=?, description=?, content=? where id=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setString(1, post.getBlogTitle());
				ps.setString(2, post.getBlogDescription());
				ps.setString(3, post.getBlogContent());
				ps.setInt(4, post.getBlogId());

				int rowCount = ps.executeUpdate();
				if (rowCount != 0) {
					return "Record updated successfully";
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Record updation failed";
	}

	@Override
	public String deleteRecordById(Integer rid) {

		String queryString = "delete from blogposts where id=?";
		try {
			if (con != null) {
				ps = con.prepareStatement(queryString);
			}
			if (ps != null) {
				ps.setInt(1, rid);

				int rowCount = ps.executeUpdate();

				if (rowCount != 0) {
					return "Record Deleted successfully for the given id " + rid;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return "Record deletion failed for the given id " + rid;
	}

}
