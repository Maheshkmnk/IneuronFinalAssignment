package in.kmnk.dto;

import java.io.Serializable;

public class BlogPost implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer blogId;
	private String blogTitle;
	private String blogDescription;
	private String blogContent;

	public Integer getBlogId() {
		return blogId;
	}

	public void setBlogId(Integer blogId) {
		this.blogId = blogId;
	}

	public String getBlogTitle() {
		return blogTitle;
	}

	public void setBlogTitle(String blogTitle) {
		this.blogTitle = blogTitle;
	}

	public String getBlogDescription() {
		return blogDescription;
	}

	public void setBlogDescription(String blogDescription) {
		this.blogDescription = blogDescription;
	}

	public String getBlogContent() {
		return blogContent;
	}

	public void setBlogContent(String blogContent) {
		this.blogContent = blogContent;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "BlogPost [blogId=" + blogId + ", blogTitle=" + blogTitle + ", blogDescription=" + blogDescription
				+ ", blogContent=" + blogContent + "]";
	}
}
