package in.kmnk.service;

import java.util.List;

import in.kmnk.dao.IStudentDao;
import in.kmnk.daofactory.StudentDaoFactory;
import in.kmnk.dto.Student;

public class StudentServiceImpl implements IStudentService {
	IStudentDao studentDao = StudentDaoFactory.getStudentService();;

	@Override
	public String insertStudent(Student student) {
		return studentDao.insertStudent(student);
	}

	@Override
	public Student getRecordById(Integer rId) {
		return studentDao.getRecordById(rId);
	}

	@Override
	public List<Student> getAllRecords() {
		return studentDao.getAllRecords();
	}

	@Override
	public String updateRecordById(Student student) {
		return studentDao.updateRecordById(student);
	}

	@Override
	public String deleteRecordById(Integer id) {
		return studentDao.deleteRecordById(id);
	}
}
