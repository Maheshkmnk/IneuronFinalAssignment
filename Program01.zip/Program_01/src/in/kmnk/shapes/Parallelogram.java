package in.kmnk.shapes;

public class Parallelogram implements IShape {

	private double base;
	private double height;
	private double side1;
	private double side2;

	public Parallelogram(double base, double height, double side1, double side2) {
		super();
		this.base = base;
		this.height = height;
		this.side1 = side1;
		this.side2 = side2;
	}

	@Override
	public Double area() {
		return base * height;
	}

	@Override
	public Double perimeter() {
		return 2 * (side1 + side2);
	}

}
